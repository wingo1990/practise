# Top-1000000-Domains
Top One Million Ranked Websites as ranked by Alexa.
Crawled from  http://stuffgate.com/stuff/website
